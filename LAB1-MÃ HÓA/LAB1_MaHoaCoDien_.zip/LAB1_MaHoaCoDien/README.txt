LAB1 Ma hoa doi xung co dien - Eclipse Java 17 Maven
1. Import: File > Import > Maven > Existing Maven Projects, chon thu muc project.
2. Maven > Update Project; Project > Clean.
3. Chay src/main/java/week_01/frm_Menu.java > Run As > Java Application.
4. SQL: chay sql/01_Tao_CSDL.sql roi 02_Tao_Login.sql bang SSMS.
5. SQL SUGAR: bat TCP/IP va chon cong dang lang nghe, mac dinh o form la 14333 (thay neu cong khac).
6. Trong frm_TongHop bam Ket noi SQL Server, Test Connection, roi ma hoa va Xem lich su.
7. Form duoc viet Java Swing truc tiep, khong can WindowBuilder.
