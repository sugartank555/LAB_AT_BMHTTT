LAB 1 - MÃ HÓA ĐỐI XỨNG CỔ ĐIỂN (ECLIPSE, JAVA 17, MAVEN, SQL SERVER)

Mã nguồn được viết bằng Swing thuần Java để chạy ngay trong Eclipse; không phụ thuộc mã GUI Builder của NetBeans.
Có đầy đủ 6 form thuật toán, form tổng hợp, kết nối SQL Server, lịch sử, tấn công mật mã và menu.

1. Eclipse: File > Import > Maven > Existing Maven Projects, chọn thư mục LAB1_MaHoaCoDien (thư mục chứa pom.xml).
2. Project > Properties > Java Build Path > Libraries: dùng JavaSE-17; Maven > Update Project.
3. Run As > Java Application trên src/main/java/week_01/frm_Menu.java để mở menu.
4. Muốn kiểm thử riêng: chạy main() của frm_Caesar, frm_Vigenere,...
5. SQL Server: trong SSMS, kết nối instance SUGAR bằng Windows Authentication, chạy 03_SQL_SERVER/01_Tao_CSDL.sql rồi 02_Tao_Login_MAU.sql.
6. SQL Server Configuration Manager > Protocols for SUGAR: bật TCP/IP, chọn cổng cố định chưa dùng (ví dụ 14333), khởi động lại đúng dịch vụ SQL Server (SUGAR).
7. Kiểm tra SSMS kết nối bằng tcp:127.0.0.1,14333. Nếu chưa được, form Java cũng chưa kết nối được; không cần cài SQL Server mới.
8. Vào form Kết nối SQL Server: Server=127.0.0.1, Port=cổng TCP đã thiết lập, Database=LAB1_MaHoaCoDien, User=lab1_user, Password=mật khẩu đã tạo trong SQL.
9. Chọn Test Connection. Sau đó về Tổng hợp và Encrypt/Decrypt, kết quả sẽ được lưu trong dbo.history; Xem lịch sử để đọc lại.
10. Nếu không kết nối SQL, tất cả thuật toán và phần tấn công mật mã vẫn hoạt động, chỉ không lưu được lịch sử.

DỮ LIỆU TEST THEO PDF:
Caesar HELLO / 3 -> KHOOR
Vigenere HELLO / KEY -> RIJVS
Rail Fence HELLO WORLD / 3 -> HOREL OLLWD
Playfair HELLOWORLD / KEYWORD -> GYIZSCOKCFBU
Transposition BAOMAT / 2,3,1 -> AAOTBM
Autokey HELLO / KEY -> RIJSS
Known plaintext HELLO / RIJVS -> KEYKE

GHI CHÚ: Các form là mã Swing tạo bằng Java, không phải file .form của NetBeans. Bạn có thể sửa giao diện trực tiếp trong mã; Eclipse WindowBuilder có thể chỉ hỗ trợ xem một phần bố cục của các form xây dựng động.
Lưu ý phần Brute Force dựa theo xác suất chữ tiếng Anh: với bản mã ngắn KHOOR, khóa k=3 hiện trong danh sách nhưng không đảm bảo được đánh dấu là tốt nhất.
