package week_01;
import java.awt.*;
import javax.swing.*;
/** Các thành phần giao diện dùng chung, không phụ thuộc WindowBuilder. */
public final class UiKit {
 private UiKit(){}
 public static JPanel panel(){JPanel p=new JPanel();p.setBorder(BorderFactory.createEmptyBorder(14,16,14,16));return p;}
 public static JLabel title(String t){JLabel l=new JLabel(t);l.setFont(new Font("Segoe UI",Font.BOLD,20));return l;}
 public static JTextArea area(){JTextArea a=new JTextArea(4,45);a.setLineWrap(true);a.setWrapStyleWord(true);a.setFont(new Font("Segoe UI",Font.PLAIN,14));return a;}
 public static void showError(Component owner,Exception ex){JOptionPane.showMessageDialog(owner,ex.getMessage(),"Dữ liệu không hợp lệ",JOptionPane.ERROR_MESSAGE);}
 public static void launch(JFrame frame){SwingUtilities.invokeLater(()->frame.setVisible(true));}
 public static JPanel row(Component... parts){JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT,9,5));for(Component c:parts)p.add(c);return p;}
 public static void close(JFrame frame,String title,int w,int h){frame.setTitle(title);frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);frame.setSize(w,h);frame.setLocationRelativeTo(null);}
}
