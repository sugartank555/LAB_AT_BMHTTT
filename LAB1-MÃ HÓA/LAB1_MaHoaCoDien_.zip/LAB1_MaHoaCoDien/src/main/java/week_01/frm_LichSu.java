package week_01;

import java.awt.*;
import javax.swing.*;
public class frm_LichSu extends JFrame {
 private static final long serialVersionUID=1L;
 private final JTable tbl_history=new JTable(HistoryDao.emptyModel());
 private final JLabel lbl_status=new JLabel("Đang tải...");
 public frm_LichSu(){setTitle("Lịch sử thao tác (SQL Server)");setSize(950,500);setLocationRelativeTo(null);setDefaultCloseOperation(DISPOSE_ON_CLOSE);JPanel foot=new JPanel(new BorderLayout());JButton refresh=new JButton("Tải lại");foot.add(refresh,BorderLayout.WEST);foot.add(lbl_status,BorderLayout.CENTER);add(new JScrollPane(tbl_history),BorderLayout.CENTER);add(foot,BorderLayout.SOUTH);refresh.addActionListener(e->loadData());loadData();}
 private void loadData(){try{tbl_history.setModel(HistoryDao.loadLatest(50));lbl_status.setText("Đã tải "+tbl_history.getRowCount()+" dòng mới nhất.");}catch(java.sql.SQLException e){lbl_status.setText("Không đọc được lịch sử: "+e.getMessage());}}
 public static void main(String[] a){SwingUtilities.invokeLater(()->new frm_LichSu().setVisible(true));}
}
