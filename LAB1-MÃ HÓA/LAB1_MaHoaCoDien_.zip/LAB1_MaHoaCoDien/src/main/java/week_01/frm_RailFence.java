package week_01;

public class frm_RailFence extends CipherFrame {
 public frm_RailFence(){super("Rail Fence");}
 public static void main(String[] a){javax.swing.SwingUtilities.invokeLater(()->new frm_RailFence().setVisible(true));}
}
