package week_01;

import java.awt.*;
import javax.swing.*;
public class frm_TanCong extends JFrame {
 private static final long serialVersionUID=1L;
 private final JTextArea txt_cipher=new JTextArea(3,40),txt_result=new JTextArea(16,50);
 private final JTextField txt_known_plain=new JTextField("HELLO"),txt_known_cipher=new JTextField("RIJVS");
 private final JLabel lbl_status=new JLabel("Sẵn sàng.");
 public frm_TanCong(){setTitle("Phân tích mật mã cổ điển");setSize(800,630);setLocationRelativeTo(null);setDefaultCloseOperation(DISPOSE_ON_CLOSE);JPanel body=new JPanel();body.setBorder(BorderFactory.createEmptyBorder(12,18,12,18));body.setLayout(new BoxLayout(body,BoxLayout.Y_AXIS));JLabel title=new JLabel("PHÂN TÍCH (TẤN CÔNG) MẬT MÃ CỔ ĐIỂN");title.setFont(new Font("Segoe UI",Font.BOLD,18));body.add(title);body.add(new JLabel("Ciphertext:"));body.add(new JScrollPane(txt_cipher));JPanel actions=new JPanel(new GridLayout(1,2));JButton brute=new JButton("Brute Force Caesar"),freq=new JButton("Frequency Analysis");actions.add(brute);actions.add(freq);body.add(actions);JPanel known=new JPanel(new GridLayout(2,2));known.add(new JLabel("Bản rõ đã biết:"));known.add(new JLabel("Bản mã:"));known.add(txt_known_plain);known.add(txt_known_cipher);body.add(known);JButton bknown=new JButton("Known Plaintext (Vigenere)");body.add(bknown);body.add(new JLabel("Kết quả:"));txt_result.setEditable(false);txt_result.setFont(new Font("Monospaced",Font.PLAIN,13));body.add(new JScrollPane(txt_result));add(body,BorderLayout.CENTER);add(lbl_status,BorderLayout.SOUTH);brute.addActionListener(e->{if(!checkCipher())return;txt_result.setText(AttackDemos.caesarBruteForce(txt_cipher.getText()));lbl_status.setText("Đã thử 26 khóa Caesar.");});freq.addActionListener(e->{if(!checkCipher())return;txt_result.setText(AttackDemos.frequency(txt_cipher.getText()));lbl_status.setText("Đã thống kê tần suất.");});bknown.addActionListener(e->{try{String key=AttackDemos.knownPlaintext(txt_known_plain.getText(),txt_known_cipher.getText());txt_result.setText("Chuỗi khóa suy ra: "+key);lbl_status.setText("Đã suy ra khóa.");}catch(Exception ex){JOptionPane.showMessageDialog(this,ex.getMessage());}});}
 private boolean checkCipher(){if(txt_cipher.getText().isBlank()){JOptionPane.showMessageDialog(this,"Hãy nhập Ciphertext.");return false;}return true;}
 public static void main(String[] a){SwingUtilities.invokeLater(()->new frm_TanCong().setVisible(true));}
}
