package week_01;

public final class CaesarCipher {
 private CaesarCipher() {}
 public static String encrypt(String t,int k){return go(t,k);}
 public static String decrypt(String t,int k){return go(t,-k);}
 private static String go(String t,int k){StringBuilder b=new StringBuilder(); for(char c:t.toCharArray()) {char a=c>='A'&&c<='Z'?'A':c>='a'&&c<='z'?'a':0; b.append(a==0?c:(char)(a+Math.floorMod(c-a+k,26)));}return b.toString();}
}
