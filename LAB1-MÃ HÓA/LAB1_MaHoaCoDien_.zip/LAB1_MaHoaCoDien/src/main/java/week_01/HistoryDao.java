package week_01;

import java.sql.*;
import javax.swing.table.DefaultTableModel;
public final class HistoryDao {
 private HistoryDao() {}
 public static void insert(String algorithm,String operation,String input,String output) throws SQLException {String sql="INSERT INTO dbo.history(algorithm,operation,input_text,result_text) VALUES(?,?,?,?)";try(Connection c=DbConfig.open();PreparedStatement ps=c.prepareStatement(sql)){ps.setString(1,algorithm);ps.setString(2,operation);ps.setString(3,input);ps.setString(4,output);ps.executeUpdate();}}
 public static DefaultTableModel emptyModel(){return new DefaultTableModel(new Object[]{"ID","Thời gian","Thuật toán","Thao tác","Đầu vào","Kết quả"},0){private static final long serialVersionUID=1L;@Override public boolean isCellEditable(int r,int c){return false;}};}
 public static DefaultTableModel loadLatest(int limit) throws SQLException{DefaultTableModel model=emptyModel();String sql="SELECT TOP (?) id,created_at,algorithm,operation,input_text,result_text FROM dbo.history ORDER BY id DESC";try(Connection c=DbConfig.open();PreparedStatement ps=c.prepareStatement(sql)){ps.setInt(1,limit);try(ResultSet rs=ps.executeQuery()){while(rs.next()){model.addRow(new Object[]{rs.getLong(1),rs.getTimestamp(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)});}}}return model;}
}
