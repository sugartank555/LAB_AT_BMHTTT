package week_01;

public final class TranspositionCipher {
 private TranspositionCipher() {}
 public static int[] parseKey(String s){String[] parts=s.trim().split("\\s*,\\s*");int[] k=new int[parts.length];try{for(int i=0;i<k.length;i++)k[i]=Integer.parseInt(parts[i]);}catch(NumberFormatException e){throw new IllegalArgumentException("Khóa phải là các số cách nhau bằng dấu phẩy, ví dụ 2,3,1.");}validate(k);return k;}
 private static void validate(int[] k){if(k==null||k.length<2||k.length>50)throw new IllegalArgumentException("Khóa phải có từ 2 đến 50 cột.");boolean[] seen=new boolean[k.length+1];for(int x:k){if(x<1||x>k.length||seen[x])throw new IllegalArgumentException("Khóa phải là hoán vị 1..m.");seen[x]=true;}}
 public static String encrypt(String t,int[] k){return go(t,k,true);}
 public static String decrypt(String t,int[] k){return go(t,k,false);}
 private static String go(String t,int[] key,boolean enc){validate(key);int[] chars=t.codePoints().toArray();int n=chars.length,cols=key.length,rows=(n+cols-1)/cols;int[][] grid=new int[rows][cols];int pos=0;int[] out=new int[n];if(enc){for(int i=0;i<n;i++)grid[i/cols][i%cols]=chars[i];for(int col:key)for(int row=0;row<rows;row++)if(row*cols+col-1<n)out[pos++]=grid[row][col-1];}else{for(int col:key)for(int row=0;row<rows;row++)if(row*cols+col-1<n)grid[row][col-1]=chars[pos++];for(int i=0;i<n;i++)out[i]=grid[i/cols][i%cols];}return new String(out,0,n);}
}
