package week_01;

public final class RailFenceCipher {
 private RailFenceCipher() {}
 public static String encrypt(String t,int rails){return go(t,rails,true);}
 public static String decrypt(String t,int rails){return go(t,rails,false);}
 private static String go(String t,int rails,boolean enc){if(rails<2||rails>1000)throw new IllegalArgumentException("Số hàng phải từ 2 đến 1000.");int[] a=t.codePoints().toArray();int n=a.length;if(rails>=n||n<=1)return t;int[] pattern=new int[n];int row=0,dir=1;for(int i=0;i<n;i++){pattern[i]=row;if(row==0)dir=1;else if(row==rails-1)dir=-1;row+=dir;}int[] out=new int[n];int pos=0;if(enc){for(int rail=0;rail<rails;rail++)for(int i=0;i<n;i++)if(pattern[i]==rail)out[pos++]=a[i];}else{int[] idx=new int[n];for(int rail=0;rail<rails;rail++)for(int i=0;i<n;i++)if(pattern[i]==rail)idx[i]=pos++;for(int i=0;i<n;i++)out[i]=a[idx[i]];}return new String(out,0,n);}
}
