package week_01;

public class frm_Playfair extends CipherFrame {
 public frm_Playfair(){super("Playfair");}
 public static void main(String[] a){javax.swing.SwingUtilities.invokeLater(()->new frm_Playfair().setVisible(true));}
}
