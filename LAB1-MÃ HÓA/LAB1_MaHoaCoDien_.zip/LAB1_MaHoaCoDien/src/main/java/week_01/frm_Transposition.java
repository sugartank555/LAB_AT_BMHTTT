package week_01;

public class frm_Transposition extends CipherFrame {
 public frm_Transposition(){super("Transposition");}
 public static void main(String[] a){javax.swing.SwingUtilities.invokeLater(()->new frm_Transposition().setVisible(true));}
}
