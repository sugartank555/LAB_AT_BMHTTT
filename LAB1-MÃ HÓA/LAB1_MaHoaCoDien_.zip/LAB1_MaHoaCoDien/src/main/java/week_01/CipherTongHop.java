package week_01;

public final class CipherTongHop {
 public static final String[] ALGORITHMS={"Caesar","Vigenere","Rail Fence","Playfair","Transposition","Autokey"};
 private CipherTongHop() {}
 public static String sampleKey(String a){return switch(a){case "Caesar","Rail Fence"->"3";case "Playfair"->"KEYWORD";case "Transposition"->"2,3,1";default->"KEY";};}
 public static String encrypt(String a,String t,String k){return run(a,t,k,true);}
 public static String decrypt(String a,String t,String k){return run(a,t,k,false);}
 private static String run(String a,String t,String k,boolean enc){if(t.isEmpty())throw new IllegalArgumentException("Chưa nhập dữ liệu.");return switch(a){case "Caesar"->{int x=parseInt(k);yield enc?CaesarCipher.encrypt(t,x):CaesarCipher.decrypt(t,x);}case "Vigenere"->enc?VigenereCipher.encrypt(t,k):VigenereCipher.decrypt(t,k);case "Rail Fence"->{int x=parseInt(k);yield enc?RailFenceCipher.encrypt(t,x):RailFenceCipher.decrypt(t,x);}case "Playfair"->enc?PlayfairCipher.encrypt(t,k):PlayfairCipher.decrypt(t,k);case "Transposition"->{int[] x=TranspositionCipher.parseKey(k);yield enc?TranspositionCipher.encrypt(t,x):TranspositionCipher.decrypt(t,x);}case "Autokey"->enc?AutokeyCipher.encrypt(t,k):AutokeyCipher.decrypt(t,k);default->throw new IllegalArgumentException("Thuật toán không hỗ trợ: "+a);};}
 private static int parseInt(String k){try{return Integer.parseInt(k.trim());}catch(NumberFormatException e){throw new IllegalArgumentException("Khóa phải là số nguyên.");}}
}
