package week_01;

import java.util.Locale;
public final class AttackDemos {
 private static final double[] ENGLISH={8.2,1.5,2.8,4.3,12.7,2.2,2.0,6.1,7.0,0.15,0.77,4.0,2.4,6.7,7.5,1.9,0.095,6.0,6.3,9.1,2.8,0.98,2.4,0.15,2.0,0.074};
 private AttackDemos() {}
 public static String caesarBruteForce(String cipher){int best=0;double highest=-Double.MAX_VALUE;for(int k=0;k<26;k++){double score=score(CaesarCipher.decrypt(cipher,k));if(score>highest){highest=score;best=k;}}StringBuilder b=new StringBuilder("k | Bản rõ thử\n");for(int k=0;k<26;k++)b.append(String.format("%2d | %s%s%n",k,CaesarCipher.decrypt(cipher,k),k==best?" <== điểm cao nhất":""));return b.append("Khóa được gợi ý: ").append(best).toString();}
 private static double score(String t){double x=0;for(char c:t.toUpperCase(Locale.ROOT).toCharArray())if(c>='A'&&c<='Z')x+=Math.log(ENGLISH[c-'A']);return x;}
 public static String frequency(String t){int[] a=new int[26];int n=0;for(char c:t.toUpperCase(Locale.ROOT).toCharArray())if(c>='A'&&c<='Z'){a[c-'A']++;n++;}if(n==0)return "Bản mã không có chữ A-Z.";StringBuilder b=new StringBuilder("Chữ | Số lần | Tần suất\n");for(int i=0;i<26;i++)if(a[i]>0)b.append(String.format(Locale.ROOT," %c | %2d | %5.1f %%\n",(char)('A'+i),a[i],100.0*a[i]/n));return b.append("Tổng số chữ: ").append(n).toString();}
 public static String knownPlaintext(String plain,String cipher){String p=plain.trim().toUpperCase(Locale.ROOT),c=cipher.trim().toUpperCase(Locale.ROOT);if(p.isEmpty()||p.length()!=c.length()||!p.matches("[A-Z]+")||!c.matches("[A-Z]+"))throw new IllegalArgumentException("Hai chuỗi phải cùng độ dài và chỉ gồm A-Z.");StringBuilder k=new StringBuilder();for(int i=0;i<p.length();i++)k.append((char)('A'+Math.floorMod(c.charAt(i)-p.charAt(i),26)));return k.toString();}
}
