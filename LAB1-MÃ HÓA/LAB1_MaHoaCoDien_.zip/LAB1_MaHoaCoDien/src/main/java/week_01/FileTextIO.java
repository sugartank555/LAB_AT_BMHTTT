package week_01;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
public final class FileTextIO {
 private FileTextIO() {}
 public static String openText(JFrame f,JTextArea area){String s=openString(f);if(s!=null)area.setText(s.trim());return lastPath;}
 private static String lastPath;
 public static String openString(JFrame f){lastPath=null;JFileChooser c=new JFileChooser();c.setFileFilter(new FileNameExtensionFilter("Text (*.txt)","txt"));if(c.showOpenDialog(f)!=JFileChooser.APPROVE_OPTION)return null;try{File file=c.getSelectedFile();String t=Files.readString(file.toPath(),StandardCharsets.UTF_8);lastPath=file.getAbsolutePath();return t;}catch(Exception e){JOptionPane.showMessageDialog(f,e.getMessage());return null;}}
 public static String saveText(JFrame f,JTextArea a,String name){if(a.getText().isBlank()){JOptionPane.showMessageDialog(f,"Chưa có nội dung để lưu.");return null;}return saveString(f,a.getText(),name);}
 public static String saveString(JFrame f,String t,String name){JFileChooser c=new JFileChooser();c.setSelectedFile(new File(name));if(c.showSaveDialog(f)!=JFileChooser.APPROVE_OPTION)return null;File file=c.getSelectedFile();if(!file.getName().toLowerCase().endsWith(".txt"))file=new File(file.getParentFile(),file.getName()+".txt");try{Files.writeString(file.toPath(),t,StandardCharsets.UTF_8);return file.getAbsolutePath();}catch(Exception e){JOptionPane.showMessageDialog(f,e.getMessage());return null;}}
}
