package week_01;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
public final class AutokeyCipher {
 private AutokeyCipher() {}
 public static String encrypt(String t,String k){return go(t,k,true);}
 public static String decrypt(String t,String k){return go(t,k,false);}
 private static String go(String t,String key,boolean enc){String k=key.trim().toUpperCase(Locale.ROOT);if(!k.matches("[A-Z]+"))throw new IllegalArgumentException("Khóa Autokey chỉ gồm A-Z.");List<Integer> plain=new ArrayList<>();StringBuilder b=new StringBuilder();int idx=0;for(char c:t.toCharArray()){char base=c>='A'&&c<='Z'?'A':c>='a'&&c<='z'?'a':0;if(base==0){b.append(c);continue;}int s=idx<k.length()?k.charAt(idx)-'A':plain.get(idx-k.length());char out=(char)(base+Math.floorMod(c-base+(enc?s:-s),26));b.append(out);plain.add((enc?c:out)-base);idx++;}return b.toString();}
}
