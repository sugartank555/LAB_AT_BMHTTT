package week_01;

import java.util.Locale;
public final class VigenereCipher {
 private VigenereCipher() {}
 public static String encrypt(String t,String k){return go(t,k,true);}
 public static String decrypt(String t,String k){return go(t,k,false);}
 private static String go(String t,String key,boolean enc){String k=key.trim().toUpperCase(Locale.ROOT);if(!k.matches("[A-Z]+"))throw new IllegalArgumentException("Khóa Vigenere chỉ gồm A-Z.");StringBuilder b=new StringBuilder();int j=0;for(char c:t.toCharArray()){char a=c>='A'&&c<='Z'?'A':c>='a'&&c<='z'?'a':0;if(a==0){b.append(c);continue;}int s=k.charAt(j++%k.length())-'A';b.append((char)(a+Math.floorMod(c-a+(enc?s:-s),26)));}return b.toString();}
}
