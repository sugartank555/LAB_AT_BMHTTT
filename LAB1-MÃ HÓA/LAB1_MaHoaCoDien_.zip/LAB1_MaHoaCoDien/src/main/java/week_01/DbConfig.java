package week_01;

import java.sql.*;
import java.util.Arrays;
public final class DbConfig {
 private static String server="127.0.0.1",db="LAB1_MaHoaCoDien",user="lab1_user";
 private static int port=14333;private static char[] password;private static boolean ready;
 private DbConfig() {}
 public static synchronized void set(String s,int p,String database,String u,char[] pass){if(p<1||p>65535)throw new IllegalArgumentException("Port không hợp lệ.");clear();server=s;port=p;db=database;user=u;password=pass.clone();ready=true;}
 public static synchronized void clear(){if(password!=null)Arrays.fill(password,'\0');password=null;ready=false;}
 public static synchronized boolean isConfigured(){return ready;}
 public static synchronized Connection open() throws SQLException {if(!ready)throw new SQLException("Chưa thiết lập tài khoản SQL.");String url="jdbc:sqlserver://"+server+":"+port+";databaseName="+db+";encrypt=true;trustServerCertificate=true;loginTimeout=5";return DriverManager.getConnection(url,user,new String(password));}
 public static String test() throws SQLException {try(Connection c=open()){DatabaseMetaData m=c.getMetaData();return "Kết nối thành công: "+m.getDatabaseProductName()+" "+m.getDatabaseProductVersion()+" - database "+c.getCatalog();}}
}
