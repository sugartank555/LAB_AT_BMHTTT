package week_01;
import java.awt.*;
import javax.swing.*;
/** Mỗi form thuật toán dùng cùng bố cục để tránh lặp lại code Swing. */
public abstract class BaseCipherFrame extends JFrame {
 protected final JTextArea txt_plaintext=UiKit.area(),txt_ciphertext=UiKit.area();
 protected final JTextField txt_key=new JTextField(18);
 protected final JLabel lbl_status=new JLabel("Sẵn sàng.");
 protected final JButton btn_encrypt=new JButton("Encrypt"),btn_decrypt=new JButton("Decrypt"),btn_open=new JButton("Open Ciphertext File"),btn_save=new JButton("Save Ciphertext File");
 protected final JPanel center=new JPanel(new GridBagLayout());
 private int row=0;
 protected final String filename;
 protected BaseCipherFrame(String title,String heading,String key,String hint,String filename){
  this.filename=filename;UiKit.close(this,title,760,510);setMinimumSize(new Dimension(610,420));
  JPanel root=UiKit.panel();root.setLayout(new BorderLayout(6,10));root.add(UiKit.title(heading),BorderLayout.NORTH);
  txt_key.setText(key);addRow("Plaintext:",new JScrollPane(txt_plaintext),1.0);addRow("Key:",UiKit.row(txt_key,new JLabel(hint)),0);addOptionalRows();addRow("Ciphertext:",new JScrollPane(txt_ciphertext),1.0);
  root.add(center,BorderLayout.CENTER);
  JPanel south=new JPanel(new BorderLayout(0,8));south.add(UiKit.row(btn_encrypt,btn_decrypt,btn_open,btn_save),BorderLayout.NORTH);south.add(lbl_status,BorderLayout.SOUTH);root.add(south,BorderLayout.SOUTH);setContentPane(root);
  btn_encrypt.addActionListener(e->apply(true));btn_decrypt.addActionListener(e->apply(false));
  btn_open.addActionListener(e->{String path=FileTextIO.openText(this,txt_ciphertext);if(path!=null)lbl_status.setText("Đã mở tệp: "+path);});
  btn_save.addActionListener(e->{String path=FileTextIO.saveText(this,txt_ciphertext,filename);if(path!=null)lbl_status.setText("Đã lưu tệp: "+path);});
 }
 protected void addOptionalRows(){}
 protected final void addRow(String title,Component component,double weight){
  GridBagConstraints g=new GridBagConstraints();g.gridx=0;g.gridy=row;g.insets=new Insets(5,4,5,9);g.anchor=GridBagConstraints.NORTHWEST;g.fill=GridBagConstraints.NONE;center.add(new JLabel(title),g);
  g.gridx=1;g.weightx=1;g.weighty=weight;g.fill=weight>0?GridBagConstraints.BOTH:GridBagConstraints.HORIZONTAL;center.add(component,g);row++;
 }
 private void apply(boolean encrypt){
  String input=encrypt?txt_plaintext.getText():txt_ciphertext.getText();if(input.isEmpty()){JOptionPane.showMessageDialog(this,"Hãy nhập "+(encrypt?"Plaintext":"Ciphertext")+" trước.");return;}
  try{String result=encrypt?encrypt(input,txt_key.getText().trim()):decrypt(input,txt_key.getText().trim());if(encrypt)txt_ciphertext.setText(result);else txt_plaintext.setText(result);lbl_status.setText(encrypt?"Đã mã hóa.":"Đã giải mã.");}
  catch(IllegalArgumentException ex){UiKit.showError(this,ex);}
 }
 protected abstract String encrypt(String text,String key);
 protected abstract String decrypt(String text,String key);
}
