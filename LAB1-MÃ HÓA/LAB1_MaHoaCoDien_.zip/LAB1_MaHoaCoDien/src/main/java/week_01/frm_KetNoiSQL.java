package week_01;

import java.awt.*;
import javax.swing.*;
public class frm_KetNoiSQL extends JFrame {
 private static final long serialVersionUID=1L;
 private final JTextField txt_server=new JTextField("127.0.0.1"),txt_port=new JTextField("14333"),txt_database=new JTextField("LAB1_MaHoaCoDien"),txt_user=new JTextField("lab1_user");
 private final JPasswordField txt_password=new JPasswordField();
 private final JLabel lbl_status=new JLabel("Chưa kết nối.");
 public frm_KetNoiSQL(){setTitle("Kết nối Microsoft SQL Server");setSize(560,360);setLocationRelativeTo(null);setDefaultCloseOperation(DISPOSE_ON_CLOSE);JPanel panel=new JPanel(new GridLayout(6,2,8,8));panel.setBorder(BorderFactory.createEmptyBorder(16,20,16,20));panel.add(new JLabel("Server:"));panel.add(txt_server);panel.add(new JLabel("Port:"));panel.add(txt_port);panel.add(new JLabel("Database:"));panel.add(txt_database);panel.add(new JLabel("User:"));panel.add(txt_user);panel.add(new JLabel("Password:"));panel.add(txt_password);JButton test=new JButton("Test Connection"),history=new JButton("Xem lịch sử");panel.add(test);panel.add(history);add(panel,BorderLayout.CENTER);add(lbl_status,BorderLayout.SOUTH);test.addActionListener(e->{char[] pass=txt_password.getPassword();try{int port=Integer.parseInt(txt_port.getText().trim());DbConfig.set(txt_server.getText().trim(),port,txt_database.getText().trim(),txt_user.getText().trim(),pass);lbl_status.setText(DbConfig.test());}catch(Exception ex){DbConfig.clear();lbl_status.setText("Kết nối thất bại.");JOptionPane.showMessageDialog(this,ex.getMessage(),"Kết nối lỗi",JOptionPane.ERROR_MESSAGE);}finally{java.util.Arrays.fill(pass,'\0');}});history.addActionListener(e->new frm_LichSu().setVisible(true));}
 public static void main(String[] x){SwingUtilities.invokeLater(()->new frm_KetNoiSQL().setVisible(true));}
}
