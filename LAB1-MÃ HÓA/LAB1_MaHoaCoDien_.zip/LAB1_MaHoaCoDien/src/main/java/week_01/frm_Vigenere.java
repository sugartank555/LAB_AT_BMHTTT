package week_01;

public class frm_Vigenere extends CipherFrame {
 public frm_Vigenere(){super("Vigenere");}
 public static void main(String[] a){javax.swing.SwingUtilities.invokeLater(()->new frm_Vigenere().setVisible(true));}
}
