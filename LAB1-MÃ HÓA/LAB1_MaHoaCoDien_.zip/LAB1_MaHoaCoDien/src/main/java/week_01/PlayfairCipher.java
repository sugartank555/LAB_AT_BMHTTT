package week_01;

import java.util.Locale;
public final class PlayfairCipher {
 private final char[][] matrix;
 public PlayfairCipher(String key){matrix=makeMatrix(key);}
 public String encrypt(String t){return process(t,true);}
 public String decrypt(String t){return process(t,false);}
 public static String encrypt(String t,String k){return new PlayfairCipher(k).encrypt(t);}
 public static String decrypt(String t,String k){return new PlayfairCipher(k).decrypt(t);}
 public static String getKeyMatrix(String k){StringBuilder b=new StringBuilder();for(char[] row:makeMatrix(k)){for(char ch:row)b.append(ch).append(' ');b.append('\n');}return b.toString();}
 private static char[][] makeMatrix(String key){String k=key.trim().toUpperCase(Locale.ROOT);if(!k.matches("[A-Z]+"))throw new IllegalArgumentException("Khóa Playfair chỉ gồm A-Z.");boolean[] used=new boolean[26];StringBuilder b=new StringBuilder();for(char c:(k+"ABCDEFGHIKLMNOPQRSTUVWXYZ").toCharArray()){if(c=='J')c='I';if(!used[c-'A']){used[c-'A']=true;b.append(c);}}char[][] m=new char[5][5];for(int i=0;i<25;i++)m[i/5][i%5]=b.charAt(i);return m;}
 private static String normalize(String t){StringBuilder b=new StringBuilder();for(char c:t.toUpperCase(Locale.ROOT).toCharArray())if(c>='A'&&c<='Z')b.append(c=='J'?'I':c);if(b.isEmpty())throw new IllegalArgumentException("Văn bản Playfair cần chữ A-Z.");return b.toString();}
 private static String pairs(String t){StringBuilder b=new StringBuilder();int i=0;while(i<t.length()){char a=t.charAt(i++);char c;if(i>=t.length()||a==t.charAt(i))c=a=='X'?'Q':'X';else c=t.charAt(i++);b.append(a).append(c);}return b.toString();}
 private int[] locate(char c){for(int r=0;r<5;r++)for(int col=0;col<5;col++)if(matrix[r][col]==c)return new int[]{r,col};throw new IllegalArgumentException("Ký tự không có trong bảng khóa.");}
 private String process(String text,boolean enc){String t=normalize(text);if(enc)t=pairs(t);else if(t.length()%2!=0)throw new IllegalArgumentException("Bản mã Playfair phải có độ dài chẵn.");StringBuilder b=new StringBuilder();int s=enc?1:4;for(int i=0;i<t.length();i+=2){int[] a=locate(t.charAt(i)),c=locate(t.charAt(i+1));if(a[0]==c[0]){b.append(matrix[a[0]][(a[1]+s)%5]);b.append(matrix[c[0]][(c[1]+s)%5]);}else if(a[1]==c[1]){b.append(matrix[(a[0]+s)%5][a[1]]);b.append(matrix[(c[0]+s)%5][c[1]]);}else{b.append(matrix[a[0]][c[1]]);b.append(matrix[c[0]][a[1]]);}}return b.toString();}
}
