package week_01;

public class frm_Autokey extends CipherFrame {
 public frm_Autokey(){super("Autokey");}
 public static void main(String[] a){javax.swing.SwingUtilities.invokeLater(()->new frm_Autokey().setVisible(true));}
}
