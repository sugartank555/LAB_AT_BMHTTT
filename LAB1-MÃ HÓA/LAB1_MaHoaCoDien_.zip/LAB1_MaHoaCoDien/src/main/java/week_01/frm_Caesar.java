package week_01;

public class frm_Caesar extends CipherFrame {
 public frm_Caesar(){super("Caesar");}
 public static void main(String[] a){javax.swing.SwingUtilities.invokeLater(()->new frm_Caesar().setVisible(true));}
}
