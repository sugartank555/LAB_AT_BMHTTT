package week_01;

import java.awt.*;
import javax.swing.*;
public class frm_Menu extends JFrame {
 private static final long serialVersionUID=1L;
 public frm_Menu(){setTitle("LAB 1 - Mã hóa đối xứng cổ điển");setSize(750,380);setLocationRelativeTo(null);setDefaultCloseOperation(EXIT_ON_CLOSE);JLabel title=new JLabel("LAB 1 - MÃ HÓA ĐỐI XỨNG CỔ ĐIỂN",SwingConstants.CENTER);title.setFont(new Font("Segoe UI",Font.BOLD,20));add(title,BorderLayout.NORTH);JPanel buttons=new JPanel(new GridLayout(3,3,10,12));buttons.setBorder(BorderFactory.createEmptyBorder(15,22,18,22));addButton(buttons,"1.1 Caesar",()->new frm_Caesar());addButton(buttons,"1.2 Vigenère",()->new frm_Vigenere());addButton(buttons,"1.3 Rail Fence",()->new frm_RailFence());addButton(buttons,"1.4 Playfair",()->new frm_Playfair());addButton(buttons,"1.5 Transposition",()->new frm_Transposition());addButton(buttons,"1.6 Autokey",()->new frm_Autokey());addButton(buttons,"Nâng cao 01 - Tổng hợp",()->new frm_TongHop());addButton(buttons,"Nâng cao 02 - Tấn công",()->new frm_TanCong());addButton(buttons,"Kết nối SQL Server",()->new frm_KetNoiSQL());add(buttons,BorderLayout.CENTER);add(new JLabel("Đóng form con không làm tắt chương trình.",SwingConstants.CENTER),BorderLayout.SOUTH);}
 private void addButton(JPanel p,String name,java.util.function.Supplier<JFrame> create){JButton b=new JButton(name);b.addActionListener(e->create.get().setVisible(true));p.add(b);}
 public static void main(String[] args){SwingUtilities.invokeLater(()->new frm_Menu().setVisible(true));}
}
